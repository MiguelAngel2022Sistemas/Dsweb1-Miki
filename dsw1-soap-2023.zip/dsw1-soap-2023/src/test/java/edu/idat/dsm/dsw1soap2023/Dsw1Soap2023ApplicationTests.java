package edu.idat.dsm.dsw1soap2023;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dsw1Soap2023ApplicationTests {

	@Test
	void contextLoads() {
	}

}
