package edu.idat.dsm.dsw1soap2023;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dsw1Soap2023Application {

	public static void main(String[] args) {
		SpringApplication.run(Dsw1Soap2023Application.class, args);
	}

}
